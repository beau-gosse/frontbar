<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Frontbar

Version: 1.1.0-beta

Frontbar is an extra for MODX Revolution that displays an admin toolbar in the front end for logged in users.

## Usage example

Simply place the following call within the `<body>` tag of your template:
```
[[Frontbar]]
```

To position Frontbar at the bottom of the page:
```
[[Frontbar? &position=`bottom`]]
```

**Available properties:**

_tpl_ => Name of the chunk serving as template. Default is _Frontbar_
',
    'changelog' => '# Frontbar 1.1.0-beta (September 11, 2016)
========================================

- Added option to change Frontbar position
- Added Template Edit menu item
- Switched to CDN for dropdown styles
- More enhancements + bug fixes

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c63e8ab962bd2b8b726a5b7b3246621f',
      'native_key' => 'frontbar',
      'filename' => 'modNamespace/88ae9899312b8e730a030cd38f84036a.vehicle',
      'namespace' => 'frontbar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3ee5a4cdb6ce8bd5c01ea40a536b648',
      'native_key' => 'frontbar.css_url',
      'filename' => 'modSystemSetting/c1d654892efbf7e8ee4cc04d2acab5cb.vehicle',
      'namespace' => 'frontbar',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9006ee0821a87c4724290d75b9309756',
      'native_key' => 'frontbar.sui_css',
      'filename' => 'modSystemSetting/545ffac442af383e39f8561b07f3e361.vehicle',
      'namespace' => 'frontbar',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd746af5f4ddce291ea3d979cc1307828',
      'native_key' => 'frontbar.sui_css_trans',
      'filename' => 'modSystemSetting/a594e3a7186bb271cd2a093ffeb24816.vehicle',
      'namespace' => 'frontbar',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d87c0172ca9b8200817cbba94b64e78',
      'native_key' => 'frontbar.fa_url',
      'filename' => 'modSystemSetting/90cb0b059d8c6b3f66c8e87efc8235b3.vehicle',
      'namespace' => 'frontbar',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8627846e2cf7aeb86b7d7e25cf862a6',
      'native_key' => 'frontbar.sui_js',
      'filename' => 'modSystemSetting/0ad5396b0188bf139503aacef4e27d2a.vehicle',
      'namespace' => 'frontbar',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d2f5fc6f31dec366e7aadc3226066ac',
      'native_key' => 'frontbar.sui_js_trans',
      'filename' => 'modSystemSetting/b3d4f1dbd3983c102b7b16f567e05eb6.vehicle',
      'namespace' => 'frontbar',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3b5b56ac4c8ec7ad49ba18c8e9be73c',
      'native_key' => 'frontbar.js_url',
      'filename' => 'modSystemSetting/522d36446f822c36a65f121494afa242.vehicle',
      'namespace' => 'frontbar',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c019c7f288085a6d120a44294ab31964',
      'native_key' => 'frontbar.jq_url',
      'filename' => 'modSystemSetting/02dabb0be6370c8500facd6cda2ff197.vehicle',
      'namespace' => 'frontbar',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '159ddc3e47cfd8d8ff9fbf4cf956915c',
      'native_key' => NULL,
      'filename' => 'modCategory/16904b6e6ebb6d1071f90e1c607e6a2d.vehicle',
      'namespace' => 'frontbar',
    ),
  ),
);