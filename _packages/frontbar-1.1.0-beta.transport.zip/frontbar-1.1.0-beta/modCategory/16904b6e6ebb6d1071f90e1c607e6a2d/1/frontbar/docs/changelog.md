# Frontbar 1.1.0-beta (September 11, 2016)
========================================

- Added option to change Frontbar position
- Added Template Edit menu item
- Switched to CDN for dropdown styles
- More enhancements + bug fixes

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
