<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Frontbar

Version: 1.2.0-beta

Frontbar is an extra for MODX Revolution that displays an admin toolbar in the front end for logged in users.

## Usage example

Simply place the following call within the `<body>` tag of your template:
```
[[!Frontbar]]
```

To position Frontbar at the bottom of the page:
```
[[!Frontbar? &position=`bottom`]]
```

**Available properties:**

`tpl` => Name of the chunk serving as template. Default is `Frontbar`
',
    'changelog' => '# Frontbar 1.2.0-beta (June 11, 2019)
========================================
- Fixed inconsistent manager session check
- Dropped JS and JQuery
- Dropped Semantic UI dependency
- Switched to CSS-only Bulma for styling
- Additional code cleanup

# Frontbar 1.1.0-beta (September 11, 2016)
========================================

- Added option to change Frontbar position
- Added Template Edit menu item
- Switched to CDN for dropdown styles
- More enhancements + bug fixes

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a7e6e9729bda9e9ca3acb3b8b2387c37',
      'native_key' => 'frontbar',
      'filename' => 'modNamespace/f5b9909c544cc5f4c42278833d75bba6.vehicle',
      'namespace' => 'frontbar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebb74acd625347c18f6cbe8aae33bf6f',
      'native_key' => 'frontbar.css_url',
      'filename' => 'modSystemSetting/ab8dd9f1f0c35deb52cf4da77df38c27.vehicle',
      'namespace' => 'frontbar',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e8f9ead07e18ae4841e58e23fb1f345',
      'native_key' => 'frontbar.bulma_css',
      'filename' => 'modSystemSetting/6b566b077e6c7b23d965e3826063faa1.vehicle',
      'namespace' => 'frontbar',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53476135e0bc7bc35a6b2467449c61ea',
      'native_key' => 'frontbar.fa_url',
      'filename' => 'modSystemSetting/2902d01c18358aa910d59564dbf693fa.vehicle',
      'namespace' => 'frontbar',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b1224cc74120a114d0061043d12b0c5',
      'native_key' => 'frontbar.fa_js',
      'filename' => 'modSystemSetting/0b389b4cb0371cce1b96f5687f49bf0c.vehicle',
      'namespace' => 'frontbar',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5882642a41f2409e5b6cda2b18f0d931',
      'native_key' => NULL,
      'filename' => 'modCategory/11b5fb7fc024025107fada8f5f15bc06.vehicle',
      'namespace' => 'frontbar',
    ),
  ),
);