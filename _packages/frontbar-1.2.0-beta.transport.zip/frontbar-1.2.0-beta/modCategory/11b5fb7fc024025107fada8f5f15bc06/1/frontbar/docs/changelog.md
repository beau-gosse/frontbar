# Frontbar 1.2.0-beta (June 11, 2019)
========================================
- Fixed inconsistent manager session check
- Dropped JS and JQuery
- Dropped Semantic UI dependency
- Switched to CSS-only Bulma for styling
- Additional code cleanup

# Frontbar 1.1.0-beta (September 11, 2016)
========================================

- Added option to change Frontbar position
- Added Template Edit menu item
- Switched to CDN for dropdown styles
- More enhancements + bug fixes

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
