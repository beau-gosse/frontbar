# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
