<?php
/**
 * This snippet displays an admin toolbar in the frontend for loggedin users.
 *
 * @package Frontbar
 * @subpackage snippet
 *
 * @author Treigh P. M. <treigh(at)kleverr.com>
 * @version 1.0.0-beta - September 5, 2016
 *
 *
 */

/* Check permissions */
if (!$modx->user->hasSessionContext('mgr') || !$modx->hasPermission('edit_document,new_document'))
    return '';

/* Set default properties */
$tpl = $modx->getOption('tpl', $scriptProperties, 'Frontbar');

/* Set appropriate parent */
$res =& $modx->resource;
$id      = $res->get('id');
$context = $modx->context->key;
$mgrURL  = MODX_MANAGER_URL;

// Respect document hierarchy, including Collections
if ($res->get('class_key') == 'CollectionContainer' || $res->get('isfolder') == 1) {
    $parent = $id;
} else {
    $parent = $res->get('parent');
}

/* Load assets */
$assetsURL = $modx->getOption('assets_url') . 'components/frontbar/';

$cssURL = $modx->getOption('frontbar.css_url', null, $assetsURL . 'css/frontbar.min.css');
$faURL  = $modx->getOption('frontbar.fa_url', null, '//maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css');
$jqURL  = $modx->getOption('frontbar.jq_url', null, $assetsURL . 'js/jquery-2.1.4.min.js');
$jqLoad = '<script>if( !window.jQuery ) document.write(\'<script src="' . $jqURL . '"><\/script>\');</script>';
$jsURL  = $modx->getOption('frontbar.js_url', null, $assetsURL . 'js/frontbar.min.js');

$modx->regClientCSS($cssURL);
$modx->regClientCSS($faURL);
$modx->regClientHTMLBlock($jqLoad);
$modx->regClientScript($jsURL);

/* Get user email address used to make gravatar url */
$profile  = $modx->user->getOne('Profile');
$email    = $profile->get('email');
$fullName = $profile->get('fullName');

/* Display Frontbar */
return $modx->getChunk($tpl, array(
    'mgrURL' => $mgrURL,
    'updateURL' => $mgrURL . '?a=resource/update&id=' . $id,
    'createURL' => $mgrURL . '?a=resource/create&parent=' . $parent . '&context_key=' . $context,
    'showSettings' => $modx->hasPermission('settings') ? 1 : 0,
    'showProfile' => $modx->hasPermission('change_profile') ? 1 : 0,
    'profileURL' => $mgrURL . '?a=security/profile',
    'msgURL' => $mgrURL . '?a=security/message',
    'settingsURL' => $mgrURL . '?a=system/settings',
    'username' => $modx->user->get('username'),
    'fullname' => $fullName,
    'gravatar' => '//www.gravatar.com/avatar/' . md5(strtolower(trim($email)))
));
