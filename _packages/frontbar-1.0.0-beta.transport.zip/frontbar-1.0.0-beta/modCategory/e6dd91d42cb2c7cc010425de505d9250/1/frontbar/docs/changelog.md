# Frontbar 1.0.1-beta (September 10, 2016)
========================================

- Added "Edit Template" menu item

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
