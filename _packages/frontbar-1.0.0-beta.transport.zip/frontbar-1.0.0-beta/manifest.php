<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Frontbar

Version: 1.0.0-beta

Frontbar is an extra for MODX Revolution that displays an admin toolbar in the front end for logged in users.

## Usage example

Simply place the following call within the `<body>` tag of your template:
```
[[Frontbar]]
```

**Available properties:**

_tpl_ => Name of the chunk serving as template. Default is _Frontbar_
',
    'changelog' => '# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '696c700f28ae94d4469cddba59828b9c',
      'native_key' => 'frontbar',
      'filename' => 'modNamespace/f9ccf987365814d212cbb08ccb10e6e9.vehicle',
      'namespace' => 'frontbar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f83f3aca74bca9b718a375fd18a237b',
      'native_key' => 'frontbar.css_url',
      'filename' => 'modSystemSetting/609b3587f5d95dada918b7c237223214.vehicle',
      'namespace' => 'frontbar',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3534c29c759ee3e9f485f0c37a9ba42',
      'native_key' => 'frontbar.fa_url',
      'filename' => 'modSystemSetting/29667725c55a04994a97c34a10aeef8e.vehicle',
      'namespace' => 'frontbar',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cff05e03dacdccf1621c762bc2bbbe7e',
      'native_key' => 'frontbar.js_url',
      'filename' => 'modSystemSetting/9cb473c4b1e680426e9b4441aff1db9b.vehicle',
      'namespace' => 'frontbar',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7b6d530c3742219952670d8ef1e70c2',
      'native_key' => 'frontbar.jq_url',
      'filename' => 'modSystemSetting/9bc2a832ce262eeabbb4d5f5c203198a.vehicle',
      'namespace' => 'frontbar',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'edadf1415d29ba9fe4cf2dd4c4adbd92',
      'native_key' => NULL,
      'filename' => 'modCategory/de36131f289e6d87f090d5ea5557def0.vehicle',
      'namespace' => 'frontbar',
    ),
  ),
);