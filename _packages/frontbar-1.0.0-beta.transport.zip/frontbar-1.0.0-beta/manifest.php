<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '',
    'changelog' => '# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'def3ef082a1fc0359635030f95f83d25',
      'native_key' => 'frontbar',
      'filename' => 'modNamespace/9f8a81319e5386a76a64278755c91c55.vehicle',
      'namespace' => 'frontbar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb54d38adecedf04a9f84894e96d1146',
      'native_key' => 'frontbar.css_url',
      'filename' => 'modSystemSetting/5a99fe3211ac5962f4e2d183b36fb4c0.vehicle',
      'namespace' => 'frontbar',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca2b961a671410662fb8d46359a1f0d2',
      'native_key' => 'frontbar.fa_url',
      'filename' => 'modSystemSetting/fbfb9074490e2f4454baeb3d6594e579.vehicle',
      'namespace' => 'frontbar',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8eefc4f2f7a1f7b8918ba4815094390',
      'native_key' => 'frontbar.js_url',
      'filename' => 'modSystemSetting/9a87e03aee853e9664279c3c5f86ab66.vehicle',
      'namespace' => 'frontbar',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73fa1a7e1d659805a3ac7382a0cf1317',
      'native_key' => 'frontbar.jq_url',
      'filename' => 'modSystemSetting/4a8c61127d3b439bc098ee1bb476a434.vehicle',
      'namespace' => 'frontbar',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '86dd812c37f49702a51afdc51cbbf064',
      'native_key' => NULL,
      'filename' => 'modCategory/91c4f7854274a0fb99ec44c358bc59f4.vehicle',
      'namespace' => 'frontbar',
    ),
  ),
);