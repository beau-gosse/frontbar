<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Frontbar

Version: 1.0.1-beta

Frontbar is an extra for MODX Revolution that displays an admin toolbar in the front end for logged in users.

## Usage example

Simply place the following call within the `<body>` tag of your template:
```
[[Frontbar]]
```

**Available properties:**

_tpl_ => Name of the chunk serving as template. Default is _Frontbar_
',
    'changelog' => '# Frontbar 1.0.1-beta (September 10, 2016)
========================================

- Added "Edit Template" menu item

# Frontbar 1.0.0-beta (September 6, 2016)
========================================

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '65b4e8bfeb80a832e7b36475b41d5306',
      'native_key' => 'frontbar',
      'filename' => 'modNamespace/74c08440150f51ecb117a6546e6648bf.vehicle',
      'namespace' => 'frontbar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '992b20e7d38da465e8362927ee84d7dd',
      'native_key' => 'frontbar.css_url',
      'filename' => 'modSystemSetting/748c0bc70e50615bb990986daf9b54e9.vehicle',
      'namespace' => 'frontbar',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed0eb45823732f7bd872eb0b9cdaaf85',
      'native_key' => 'frontbar.fa_url',
      'filename' => 'modSystemSetting/5cca15cc24a134803c1b7881eba1e8b3.vehicle',
      'namespace' => 'frontbar',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '786c734af3414a4f0526f06a49bd1044',
      'native_key' => 'frontbar.js_url',
      'filename' => 'modSystemSetting/e7b793c8e233a996ef1dcd7eb592b407.vehicle',
      'namespace' => 'frontbar',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07a9c29fd7736a0c91c9a8fb559628db',
      'native_key' => 'frontbar.jq_url',
      'filename' => 'modSystemSetting/9ab03b8433374308eb91ebf4f127d774.vehicle',
      'namespace' => 'frontbar',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3709c8e398cdf7a73c4a22a536ce2e2f',
      'native_key' => NULL,
      'filename' => 'modCategory/e6dd91d42cb2c7cc010425de505d9250.vehicle',
      'namespace' => 'frontbar',
    ),
  ),
);